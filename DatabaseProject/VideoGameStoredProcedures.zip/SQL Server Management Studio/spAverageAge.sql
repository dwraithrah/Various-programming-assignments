
CREATE PROCEDURE spAverageAge 
AS
BEGIN
	SELECT AVG(age) as AverageAge
	FROM [Video Game Enthusiast]
END
GO
